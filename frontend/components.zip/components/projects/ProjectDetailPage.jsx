"use client";

import ProjectBreadcrumbs from "./ProjectBreadcrumbs";
import ProjectHero from "./ProjectHero";
import ProjectTasks from "./ProjectTasks";
import ProjectSectionGrid from "./ProjectSectionGrid";

import "@/styles/pages/project-detail.css";

export default function ProjectDetailPage() {
  return (
    <main className="project-detail-page">

      <ProjectBreadcrumbs />

      <ProjectHero />

      <ProjectTasks />

      <ProjectSectionGrid />

    </main>
  );
}