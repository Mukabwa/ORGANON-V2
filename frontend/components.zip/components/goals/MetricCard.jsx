"use client";

export default function MetricCard({
  title,
  icon,
  value,
  subtitle,
  children,
}) {
  return (
    <div className="metric-card">

      <div className="metric-header">

        <span className="metric-icon">
          {icon}
        </span>

        <span className="metric-title">
          {title}
        </span>

      </div>

      <div className="metric-body">
        {children}
      </div>

      <h3 className="metric-value">
        {value}
      </h3>

      <p className="metric-subtitle">
        {subtitle}
      </p>

    </div>
  );
}