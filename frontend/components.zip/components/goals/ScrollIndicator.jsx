"use client";

export default function ScrollIndicator() {
  return (
    <div className="scroll-indicator">

      <span>Scroll</span>

      <span>↓</span>

    </div>
  );
}