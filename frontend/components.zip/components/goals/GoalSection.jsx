"use client";

import GoalHero from "./GoalHero";
import GoalProgress from "./GoalProgress";
import GoalMetrics from "./GoalMetrics";
import GoalSticker from "./GoalSticker";
import ScrollIndicator from "./ScrollIndicator";

export default function GoalSection({ goal, index }) {
  return (
    <section className="goal-section">

      <div className="goal-body">

        <GoalHero goal={goal} />

        <GoalProgress progress={goal.progress} />

        <GoalMetrics goal={goal} />

        <GoalSticker goal={goal} />

        <ScrollIndicator />

      </div>

    </section>
  );
}