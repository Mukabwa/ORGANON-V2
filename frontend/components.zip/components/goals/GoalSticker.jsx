"use client";

export default function GoalSticker() {
  return (
    <div className="goal-sticker">

      🌸 Progress over perfection.

    </div>
  );
}