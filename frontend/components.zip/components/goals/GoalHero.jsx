"use client";

export default function GoalHero({ goal }) {
  return (
    <div className="goal-hero">

      <div className="goal-number">
        {goal.number}
      </div>

      <h2 className="goal-title">
        {goal.title}
      </h2>

      <p className="goal-subtitle">
        {goal.subtitle}
      </p>

    </div>
  );
}