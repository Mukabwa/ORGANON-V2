"use client";

import MetricCard from "./MetricCard";

export default function GoalMetrics() {
  return (
    <div className="goal-metrics">

      <MetricCard
        title="Progress"
        icon="○"
        value="72%"
        subtitle="Overall completion"
      >
        <div className="placeholder-ring" />
      </MetricCard>

      <MetricCard
        title="Consistency"
        icon="💧"
        value="91%"
        subtitle="Consistency"
      >
        <div className="placeholder-drop" />
      </MetricCard>

      <MetricCard
        title="Momentum"
        icon="☄"
        value="Building"
        subtitle="Current pace"
      >
        <div className="placeholder-comet" />
      </MetricCard>

      <MetricCard
        title="Contributions"
        icon="✦"
        value="327"
        subtitle="Completed tasks"
      >
        <div className="placeholder-stars">
          ✦ ✦ ✦
        </div>
      </MetricCard>

    </div>
  );
}