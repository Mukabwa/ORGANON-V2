"use client";

export default function GoalProgress({ progress }) {
  return (
    <div className="goal-progress">

      <span className="progress-label">
        Overall Progress
      </span>

      <div className="progress-row">

        <span className="progress-value">
          {progress}%
        </span>

        <div className="progress-bar">

          <div
            className="progress-fill"
            style={{
              width: `${progress}%`,
            }}
          />

        </div>

      </div>

    </div>
  );
}