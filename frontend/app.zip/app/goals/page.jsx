"use client";

import AppShell from "@/components/shell/AppShell";

import GoalsHeader from "@/components/goals/GoalsHeader";
import GoalSection from "@/components/goals/GoalSection";

import "@/styles/pages/goals.css";

const goals = [
  {
    id: 1,
    number: "01",
    title: "Build Organon",
    subtitle: "A planner that actually fits into people's lives.",
    progress: 72,
  },
  {
    id: 2,
    number: "02",
    title: "Graduate University",
    subtitle: "One last push.",
    progress: 64,
  },
];

export default function GoalsPage() {
  return (
    <AppShell>
      <main className="goals-content">

        <GoalsHeader />

        {goals.map((goal, index) => (
          <GoalSection
            key={goal.id}
            goal={goal}
            index={index}
          />
        ))}

      </main>
    </AppShell>
  );
}